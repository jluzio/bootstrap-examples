
function test_fc() {
	console.log('test_fc');
}